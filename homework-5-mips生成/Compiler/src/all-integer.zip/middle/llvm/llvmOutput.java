package middle.llvm;

import java.util.ArrayList;

public interface llvmOutput {
    String llvmOutput();
}
