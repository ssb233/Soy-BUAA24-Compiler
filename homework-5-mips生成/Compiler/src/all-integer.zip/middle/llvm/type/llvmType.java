package middle.llvm.type;

import middle.llvm.llvmOutput;

import java.util.ArrayList;

public class llvmType implements llvmOutput {
    @Override
    public String llvmOutput() {
        return null;
    }
}
