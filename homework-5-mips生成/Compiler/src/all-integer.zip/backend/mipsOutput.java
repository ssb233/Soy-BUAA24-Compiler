package backend;

public interface mipsOutput {
    String mipsOutput();
}
