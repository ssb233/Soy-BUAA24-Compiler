package backend.mipsInstruction.compare;

public class mipsInsBge extends mipsInsCompare{
    public mipsInsBge(int first, int second, String label){
        super(first,second,label,"bge");
    }
}
