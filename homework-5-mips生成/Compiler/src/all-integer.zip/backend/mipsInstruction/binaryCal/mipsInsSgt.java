package backend.mipsInstruction.binaryCal;

public class mipsInsSgt extends mipsInsCal{
    public mipsInsSgt(int result, int first, int second){
        super(result,first,second,"sgt");
    }
}
