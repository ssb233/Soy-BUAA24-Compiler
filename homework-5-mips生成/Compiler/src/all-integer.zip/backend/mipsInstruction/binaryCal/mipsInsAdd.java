package backend.mipsInstruction.binaryCal;

import backend.RegisterNameTable;

public class mipsInsAdd extends mipsInsCal{
    public mipsInsAdd(int result, int first, int second){
        super(result,first,second,"addu");
    }


}
