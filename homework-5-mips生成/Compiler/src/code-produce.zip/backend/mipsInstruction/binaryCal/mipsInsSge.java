package backend.mipsInstruction.binaryCal;

public class mipsInsSge extends mipsInsCal{
    public mipsInsSge(int result, int first, int second){
        super(result,first,second,"sge");
    }
}
