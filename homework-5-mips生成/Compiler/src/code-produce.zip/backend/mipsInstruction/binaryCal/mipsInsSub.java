package backend.mipsInstruction.binaryCal;

public class mipsInsSub extends mipsInsCal{
    public mipsInsSub(int result, int first, int second){
        super(result,first,second,"subu");
    }
}
