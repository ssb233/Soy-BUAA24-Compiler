package backend.mipsInstruction.compare;

public class mipsInsBgt extends mipsInsCompare{
    public mipsInsBgt(int first, int second, String label){
        super(first,second,label,"bgt");
    }
}
