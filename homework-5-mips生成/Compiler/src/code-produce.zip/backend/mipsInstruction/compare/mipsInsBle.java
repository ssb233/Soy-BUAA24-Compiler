package backend.mipsInstruction.compare;

public class mipsInsBle extends mipsInsCompare{
    public mipsInsBle(int first, int second, String label){
        super(first,second,label,"ble");
    }
}
