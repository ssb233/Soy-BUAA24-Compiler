package backend.mipsInstruction.compare;

public class mipsInsBlt extends mipsInsCompare{
    public mipsInsBlt(int first, int second, String label){
        super(first,second,label,"blt");
    }
}
