package middle.symbol;

public class GlobalSymbol {
    public static int tableId = 0;
    
}
