package frontend.parser.Exp;

import frontend.parser.parserOutput;

public class PrimaryExpExtend implements parserOutput {

    @Override
    public String output() {
        return null;
    }
    public int getValue(){
        return 0;
    }
}
