package backend.mipsInstruction.compare;

public class mipsInsBne extends mipsInsCompare{
    public mipsInsBne(int first, int second, String label){
        super(first,second,label,"bne");
    }
}
