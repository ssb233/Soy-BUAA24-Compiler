package backend.mipsInstruction.binaryCal;

public class mipsInsMul extends mipsInsCal{
    public mipsInsMul(int result, int first, int second){
        super(result,first,second,"mul");
    }
}
