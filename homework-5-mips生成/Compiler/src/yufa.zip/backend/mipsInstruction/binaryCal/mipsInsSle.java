package backend.mipsInstruction.binaryCal;

public class mipsInsSle extends mipsInsCal{
    public mipsInsSle(int result, int first, int second){
        super(result,first,second,"sle");
    }
}
