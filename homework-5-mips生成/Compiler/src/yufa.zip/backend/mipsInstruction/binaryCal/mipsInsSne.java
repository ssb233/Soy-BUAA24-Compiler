package backend.mipsInstruction.binaryCal;

public class mipsInsSne extends mipsInsCal{
    public mipsInsSne(int result, int first, int second){
        super(result,first,second,"sne");
    }
}
