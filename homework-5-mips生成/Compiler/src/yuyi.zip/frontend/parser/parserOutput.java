package frontend.parser;

public interface parserOutput {
    public String output();
}
