package backend.mipsInstruction.binaryCal;

public class mipsInsSlt extends mipsInsCal{
    public mipsInsSlt(int result, int first, int second){
        super(result,first,second,"slt");
    }
}
