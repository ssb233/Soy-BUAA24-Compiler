package backend.mipsInstruction.binaryCal;

public class mipsInsSeq extends mipsInsCal{
    public mipsInsSeq(int result, int first, int second){
        super(result,first,second,"seq");
    }
}
