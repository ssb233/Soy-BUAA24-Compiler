package middle.llvm.type;

import java.util.ArrayList;

public class llvmLabelType extends llvmType{
    public llvmLabelType(){}
    public String  llvmOutput(){
        return null;
    }
}
